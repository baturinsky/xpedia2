New version of XPedia. Parses OXCE mod files and presents them as wiki-like.
Will parse mods that are selected in game, so works not just with XPiratez, but with XCF, 40k etc.

To actually parse files you will have to launch it in client-server mode in any of the ways described further.

Once you do that, you will have a button on front page to export currently parsed mods as a standalone HTML file 
which will work without server and does not need any extra files.

NOTE: Once xpedia has loaded and parsed files, it will keep a cache of them in browser. 
To re-load data press ⭯ button at the top right of GUI.

So, to run this in client-server mode:

Put this dir as a subdir of the OXCE dir or the mods dir.
Xpedia will either load mods selected in-game, or all mods next to xpedia2 dir.

Then you have to launch the server in one of the following ways

= On Windows =

Launch xpedia.bat in xpedia2 dir

= On any platform with node.js =

You don't actually need these files for that, as you will install and run from github.

In OXCE dir or mods dir:

```
git clone https://github.com/baturinsky/xpedia2
cd xpedia2
npm install 
npm start
```

= On any platform, using your own http server =

Alternatively, instead of launching xpedia.bat, run any http server with the OXCE or mods dir as the root. 
I recommend https://github.com/TheWaWaR/simple-http-server
Then open xpedia2/index.html through that server. Use xpedia.bat as an example of how to set it up.
